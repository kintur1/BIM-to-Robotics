# Parses IFC files and converts to SDF
