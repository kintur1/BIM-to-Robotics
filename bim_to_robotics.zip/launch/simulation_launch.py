# Launch robot, environment, MoveIt
