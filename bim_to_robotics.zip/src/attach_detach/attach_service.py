# ROS 2 service to attach links in Gazebo
