# ROS 2 node for pick and place task
