// Gazebo Ignition C++ plugin for link attachment
